#include "DString.h"

//��next���M���F
void GetNext(DString keyword, int next[])
{
	int j = 1, k = 0;
	next[0] = -1;
	next[1] = 0;
	while (j < keyword.length-1)
	{
		if (keyword.str[j] == keyword.str[k])
		{
			next[j + 1] = k + 1;
			j++;
			k++;
		}
		else if (k == 0)
		{
			next[j + 1] = 0;
			j++;
		}
		else
		{
			k = next[k];
		}
	}
}

//KMP�㷨���F
int KMPIndex(DString Mail, int start, DString keyword, int next[])
{
	int i = start, j = 0, v;
	while (i < Mail.length && j < keyword.length)
	{
		if (Mail.str[i] == keyword.str[j])
		{
			i++;
			j++;
		}
		else if (j == 0)
		{
			i++;
		}
		else
		{
			j = next[j];
		}
	}
	if (j == keyword.length)
	{
		v = i - keyword.length;
	}
	else
	{
		v = -1;
	}
	return v;
}